package com.plabon.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { JarvisScreen(onSpeak = { speak(it) }) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("bn", "BD")
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun JarvisScreen(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    var onlineMode by remember { mutableStateOf(false) }
    var listening by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Offline mode · local demo") }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("শুভেচ্ছা। আমি Jarvis—তোমার ব্যক্তিগত সহকারী। এখন অফলাইন ডেমো মোডে কাজ করছি। কীভাবে সাহায্য করতে পারি?", false)
        )
    }
    val listState = rememberLazyListState()

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        listening = false
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = spoken
        status = if (spoken.isNullOrBlank()) "কথা শনাক্ত করা যায়নি" else "কথা লেখা হয়েছে"
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            listening = true
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Jarvis-কে বলো…")
            }
            try { speechLauncher.launch(intent) }
            catch (_: Exception) { listening = false; status = "এই ফোনে speech recognition পাওয়া যায়নি" }
        } else status = "ভয়েস ইনপুটের জন্য মাইক্রোফোন অনুমতি দরকার"
    }

    fun sendMessage() {
        val text = input.trim()
        if (text.isEmpty()) return
        messages.add(ChatMessage(text, true))
        input = ""
        val answer = offlineReply(text)
        messages.add(ChatMessage(answer, false))
        status = if (onlineMode) {
            "Online mode selected · API backend not connected yet"
        } else "Offline mode · local demo"
        // The first build intentionally uses a local responder. Online AI requires a secure backend.
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("JARVIS", fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("PERSONAL AI ASSISTANT", fontSize = 10.sp, letterSpacing = 1.5.sp)
                    }
                },
                actions = {
                    IconButton(onClick = { onlineMode = !onlineMode }) {
                        Icon(if (onlineMode) Icons.Default.Wifi else Icons.Default.WifiOff, "Toggle mode")
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Jarvis-কে মেসেজ দাও…") },
                        maxLines = 4,
                        shape = RoundedCornerShape(24.dp)
                    )
                    IconButton(
                        onClick = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                                == PackageManager.PERMISSION_GRANTED) {
                                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Jarvis-কে বলো…")
                                }
                                try { speechLauncher.launch(intent) } catch (_: Exception) { status = "ভয়েস ইনপুট পাওয়া যায়নি" }
                            } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    ) { Icon(Icons.Default.Mic, "Speak") }
                    IconButton(onClick = { sendMessage() }) {
                        Icon(Icons.Default.Send, "Send")
                    }
                }
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).background(Color(0xFF07111F))
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(8.dp).background(if (onlineMode) Color(0xFF45D6A8) else Color(0xFF67B7FF), CircleShape))
                Spacer(Modifier.width(8.dp))
                Text(
                    if (onlineMode) "ONLINE MODE (NOT CONNECTED)" else "OFFLINE DEMO",
                    color = Color(0xFFB9CDE2), fontSize = 11.sp, letterSpacing = 1.sp
                )
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { messages.clear(); messages.add(ChatMessage("চ্যাট পরিষ্কার করা হয়েছে। কীভাবে সাহায্য করতে পারি?", false)) }) {
                    Text("Clear")
                }
            }
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                state = listState,
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { message ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
                    ) {
                        Column(
                            Modifier.widthIn(max = 320.dp)
                                .background(
                                    if (message.fromUser) Color(0xFF174A6B) else Color(0xFF142235),
                                    RoundedCornerShape(18.dp)
                                )
                                .padding(14.dp)
                        ) {
                            Text(if (message.fromUser) "তুমি" else "JARVIS", color = Color(0xFF73D5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text(message.text, color = Color(0xFFF1F6FC), fontSize = 15.sp)
                            if (!message.fromUser) {
                                TextButton(onClick = { onSpeak(message.text) }, contentPadding = PaddingValues(0.dp)) {
                                    Icon(Icons.Default.VolumeUp, null, modifier = Modifier.size(16.dp), tint = Color(0xFF73D5FF))
                                    Spacer(Modifier.width(4.dp))
                                    Text("শুনুন", color = Color(0xFF73D5FF), fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
            Text(status, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), color = Color(0xFF71869D), fontSize = 11.sp)
        }
    }
}

private fun offlineReply(raw: String): String {
    val text = raw.lowercase(Locale.ROOT)
    return when {
        listOf("হ্যালো", "হাই", "hello", "hi", "assalamu", "আসসালামু").any { text.contains(it) } ->
            "হ্যালো! আমি Jarvis। বলো, কী নিয়ে সাহায্য করব?"
        listOf("তোমার নাম", "তুমি কে", "your name", "who are you").any { text.contains(it) } ->
            "আমার নাম Jarvis। আমি তোমার ব্যক্তিগত AI সহকারীর প্রাথমিক সংস্করণ।"
        listOf("সময়", "কয়টা বাজে", "time").any { text.contains(it) } ->
            "আমি এই ডেমোতে লাইভ সময় পড়ছি না। ফোনের স্ট্যাটাস বার বা ঘড়ি দেখে নিতে পারো।"
        listOf("তুমি কি পারো", "সাহায্য", "help", "কি করতে পার").any { text.contains(it) } ->
            "এখন আমি সাধারণ কিছু বাংলা অভিবাদন ও প্রশ্নের উত্তর দিতে পারি। অনলাইন AI, স্মৃতি ও ফোনের কাজের সুবিধা পরবর্তী ধাপে যোগ করতে হবে।"
        else ->
            "আমি তোমার কথা পেয়েছি: “$raw”। এই সংস্করণে এখনো পূর্ণ AI মডেল যুক্ত নেই। অনলাইন AI সংযোগ যোগ করলে আরও বুদ্ধিমান উত্তর দিতে পারব।"
    }
}
