# Jarvis AI — Android MVP (v0.1.0)

A starter Android project for a personal Bengali-first assistant with a chat UI, Android speech input, and text-to-speech output.

## What works in this starter
- Native Android app UI using Kotlin and Jetpack Compose.
- Text chat interface.
- Basic local/offline rule-based replies.
- Voice input via Android speech recognition (speech recognition may rely on a device service/network).
- Spoken replies using Android TextToSpeech (Bengali voice availability depends on installed TTS engines).
- Online/offline mode indicator.

## What is not implemented yet
- A real online LLM connection. The Online toggle is only a UI placeholder.
- A fully offline on-device language model.
- Persistent chat history, user memory, app actions, or wake-word listening.
- Always-on voice conversations.

## Build requirements
- Android Studio (recommended), JDK 17, Android SDK Platform 35.
- Open this folder in Android Studio and let Gradle sync.
- Build > Build Bundle(s) / APK(s) > Build APK(s).
- Install the generated debug APK on your Android device for testing.

## Permissions
The app asks for microphone permission only when you tap the microphone button. Internet permission is declared for a future online connection.

## Online AI architecture (next step)
Do not put a private AI API key inside the Android app. APKs can be inspected and keys extracted.
Create a small HTTPS backend that stores the provider API key securely; the app sends user messages to that backend. Configure authentication, rate limits, privacy controls, and clear error handling.

## Suggested next milestones
1. Persist chat history with Room.
2. Add a secure backend endpoint for online AI.
3. Add user-controlled memory with review/delete controls.
4. Improve speech handling and test Bengali TTS on target phones.
5. Add offline model support only after measuring model size, speed, and RAM requirements.

## Important
This is a starter project, not a production-ready assistant. Test on real devices before sharing.
